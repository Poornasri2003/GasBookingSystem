<?php
include "connection.php";
if(isset($_POST['approve']))
{
  $email=$_POST['email'];
  echo "<script>
  alert('approval sucseeful!!');
  </script>";
  $sql="UPDATE id set status='approved' where email='$email'";
  
  if ($conn->query($sql) ===TRUE) {
    echo'<script>
    window.location.href="admindash.php";
    </script>';
  }}else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  
}
  $conn->close();
  ?>

  