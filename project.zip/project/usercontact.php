<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>adminmessages</title>
    <link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body background="image\burnner.jpeg">

   
  <div id="form" >
  <h1>queries or feedback</h1>
    <form name="form" action="usermail.php" method="POST">
    <label >name:</label>
      <input type="text" id="user" name="user"><br><br>
      <label >email:</label>
      <input type="text" id="email" name="email"><br><br>
      <label>refid:</label> 
      <input type="text" id="refid" name="refid"><br><br>
      <label >body:</label>
      <input type="text" id="sub" name="sub"><br><br>
      <input type="submit"  name="submit" value="submit">
      <br>

</form>
</div>
</body>
</html>