<?php
include("connection.php");
$refid=$_POST['refid'];

$email=$_POST['email'];
$sql = "INSERT INTO register values('$refid','$email')";
$value="UPDATE details set refid='$refid' where email='$email'";
if ($conn->query($sql) === TRUE) {
  if($conn->query($value)== TRUE){
  echo '<script>
    window.location.href="admindash.php";
    alert("successfully sent");
    </script>' ;
} }
?> 