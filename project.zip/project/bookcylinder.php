<?php
include 'connection.php';
$refid=$_POST['refid'];
$datesub=$_POST['date'];
$sql= "SELECT * from details where refid='$refid'";
$result=mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width, initial-scale=1.0">
            <title>check details</title>
            <link rel="stylesheet" type="text/css" href="signup.css">
            <script type="text/javascript"
        src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js">
</script>
<script type="text/javascript">
   (function(){
      emailjs.init("DYxf-LxIBZZBCbGV-");
   })();
</script>
<script src="scrip.js"></script>
        </head>
        <body background="image\yyy.png">
          
          <div id="form" >
          <form name="form" action="booking.php" method="POST">
        <label >refid:</label>
        <input type="text" id="refid" name="refid" value="<?php  echo''.$row['refid'];?>"><br>
        <label>email:</label>
              <input type="email" id="email" name="email" value="<?php echo''.$row['email'];?>" ><br>
              <label>Username:</label>
              <input type="user" id="user" name="user" value="<?php echo''.$row['name'];?>" >
              <label>Mobile:</label>
              <input type="text" id="mobile" name="mobile" value="<?php echo''.$row['mobile'];?>" >
              <label>Address:</label>
              <input type="text" id="address" name="address" value="<?php echo''.$row['address'];?>" >
              <label>aadhar:</label>
              <input type="text" id="aadhar" name="aadhar" value="<?php echo''.$row['aadhar'];?>" >
              <input type="hidden" id="datesub" name="datesub" value="<?php echo''.$datesub;?>" ><br>
              <input type="submit" onclick="sendMail()" value="confirm for booking">

    </form>
        </div>
        </body>
        </html>
    <?php
    }
  } 

else{
    echo '<script>
    alert("details not found")
    </script>';

}
?>