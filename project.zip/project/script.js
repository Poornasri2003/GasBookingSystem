function sendMail(){
    let parms={

        email: document.getElementById("email").value,
       
        message:document.getElementById("refid").value,
  }
  emailjs.send("service_z0jdv69","template_ewqlgml",parms).then(alert("Email sent!!!!"));
}