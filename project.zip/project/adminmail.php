<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contactuser</title>
    <link rel="stylesheet" type="text/css" href="adminmail.css">

</head>
<body background="image\zzz.png">
<div id="form" >
    <h1>Contact user</h1>
    <form name="form" action="adminmailstore.php" method="POST">
      <label >Username:</label>
      <input type="text" id="user" name="user"><br><br>
      <label>email:</label> 
      <input type="text" id="email" name="email"><br><br>
      <label>refid:</label> 
      <input type="text" id="refid" name="refid"><br><br>
      <label>body:</label> 
      <input type="text" id="sub" name="sub"><br><br>
      <input type="submit"  value="send">
      <br>
    </form>
</div>
</body>
</html>