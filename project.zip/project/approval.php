<?php
include "connection.php";
if(isset($_POST['approve']))
{
  $mobile=$_POST['mobile'];
  $email=$_POST['email'];
  $select="UPDATE details set status='approved' where mobile=$mobile";
  $result=mysqli_query($conn,$select);
  echo "<script>
  alert('approval sucseeful!!');
  </script>";
  ?>
  <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=<, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Document</title>
  <script type="text/javascript"
        src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js">
</script>
<script type="text/javascript">
   (function(){
      emailjs.init("DYxf-LxIBZZBCbGV-");
   })();
</script>
<script src="script.js"></script>
</head>
<body background="image\yyy.png">
  
  <div id="form" >
    <h1>mail</h1>
   <form name="form" action="mail.php" method="POST">
   <label>reference id:</label> 
      <input type="text" id="refid" name="refid"><br><br>
      
      <label >Email:</label>
      <input type="email" id="email" name="email" value="<?php echo''.$email;?>" ><br><br>

      <input type="submit" onclick="sendMail()"  value="send">

      <br>
</body>
</html>
<?php

}
else
{
  $mobile=$_POST['mobile'];
  $select="DELETE from details where mobile='$mobile'";
  $result=mysqli_query($conn,$select);
  echo "<script>
  alert('approval sucseeful!!');
  </script>";
}