<?php
include 'connection.php';
if(isset($_POST['delete']))
{
  $subject=$_POST['sub'];
  $select="DELETE from adminmail where sub='$subject'";
  $result=mysqli_query($conn,$select);
  echo "<script>
  alert('deleted successful!!');
  window.location.href='mailindex.php';
  </script>";
}
if(isset($_POST['view']))
{
  $subject=$_POST['sub'];
  $select="UPDATE  adminmail set state='viewed' where sub='$subject'";
  $result=mysqli_query($conn,$select);
  echo "<script>
  alert('message status updated');
  window.location.href='mailindex.php';
  </script>";

}
?>