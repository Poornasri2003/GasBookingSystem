<?php
include("connection.php");
$username=$_POST['user'];
$email=$_POST["mail"];
$mobile=$_POST["mobile"];
$gender=$_POST["gender"];
$password=$_POST["pass"];

$sql = "INSERT INTO logincredential values('$username','$email','$mobile','$gender','$password')";

if ($conn->query($sql) === TRUE) {
  echo '<script>
    window.location.href="newlogin.php";
    alert("successfully signed up.Please login to your account");
    </script>' ;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>