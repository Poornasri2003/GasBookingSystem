<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include 'connection.php';
$sql = "SELECT * from id where status= 'pending'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='5'><tr>
<th>refid</th>
<th>status</th>

</tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>".$row["refid"]."</td><td>".$row["status"]."</td>
"?><td> 
<form action="bookingapproval.php" method="POST">

  <input type="hidden" name="email" value="<?php echo $row['email'];?>">
<input type="submit" name="approve" value="approve">
</form>
</td>
</tr>";
<?php
  }
  echo "</table>";
} 
$conn->close();
?>
</body>
</html>