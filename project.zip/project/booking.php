<?php
include("connection.php");
$refid=$_POST['refid'];

$email=$_POST['email'];
$datesub=$_POST['datesub'];
$status="pending";
$sql = "INSERT INTO id values('$refid','$email','$datesub','$status')";
if ($conn->query($sql) === TRUE) {
  echo '<script>
    alert("successfully sent");
    window.location.href="userdash.php";
    </script>' ;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>