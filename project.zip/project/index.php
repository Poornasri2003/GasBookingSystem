<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body >
    <nav>
        <div>
      <label class="logo">ONLINE GAS BOOKING SYSTEM</label>
      
      </label>
      <ul>
        <li><a class="active" href="#">Home</a></li>
        <li><a href="newlogin.php">Sign up</a></li>
        <li><a href="adminlogin.html">Admin</a></li>
        
      </ul>
</div>
</nav>
      

           <div class="row">
  <div class="column1">
    <div class="card"> 
    <br><b><h1>HP GAS BOOKING</h1></b>  
    <p>Hindustan Petroleum Corporation Limited (HPCL) is one of the oldest and popular LPG suppliers in India. HPCL supplies LPG gas cylinders under the brand name HP Gas. HP Gas has a huge customer base of over 85 million customers that are catered through an extensive network of more than 6000 LPG distributors across the country. Though LPG is primarily used for domestic cooking purposes, it is also used by several industries and plants for commercial purposes.
HP Gas Booking can be made through the nearest local distributor or through the online modes of the company. In this guide, you can find all that you need to know about booking HP Gas cylinders, online and offline.
</p>
<br>
<h1>HP Gas Online Transfer Process</h1>
These days everybody prefers online transactions regarding gas connections as it is quite cumbersome to go to the office, wait about and do the needful.
<ul>
Since you are already an HP customer, please follow the steps mentioned below to transfer your LPG gas connection online.

<li>Open your official HP gas website (home page).</li>
<li>Drop the list from Quick Link column on HP Gas website homepage</li>
<li>From dropped list, please choose your specific HP Gas Customer Zone</li>
<li>It will take you to another page where you have two choices, one for current member and the other for non-members.</li>
<li>Being an old member, you can merely log in to your HP gas account and put in the transfer request by filling out the <li>relevant transfer application form and submitting it.</li>
<li>
Non Members too can easily solve their dilemma by getting himself/ herself listed first. This can be done by a single click and you may comply with the given instructions then or later.</li>
<li>The procedure of signing up process is quite simple and you shall use the same account for various other purposes like putting in complaints, too book for cylinder refills and so on. You can select the particular form, fill it duly and submit.</li>

    </div>
  </div>
  <div class="column2">
    <div class="card" id="det">
    
    <img src="image\cylin.png">

<br>
contact=8903602219<br>
mail1=xx@gmal.com<br>
<h1>book now</h1>
</div>
</div>
   
</div>
</body>
</html>