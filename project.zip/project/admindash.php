<?php
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="admindash.css">
</head>
<body>

<div class="slideshow-container">



<div class="mySlides fade">
  <div>
    <nav>
  <label class="logo">ADMIN</label>
  
  </label>
  <ul>
    <li><a class="active" href="#">Home</a></li>
    <li><a href="adminapproval.php">REGISTER APPROVAL</a></li>
    <li><a href="confirmationbooking.php">BOOkING APPROVAL</a></li>
    <li><a href="adminviewbooking.php">VIEW BOOKED HISTORY</a></li>
    <li><a href="adminmail.php">CONTACT USER</a></li>
    <li><a href="adminmailview.php">SENT MESSAGES</a><li>
    <li><a href="userqueryadmin.php">USER QUERY</a><li>
    <li><a href="index.php">LOG OUT</a></li>
    
  </ul>
</nav>
  </div>
  <img src="image\img2 (2).jpeg" style="width:100%">
</div>

<div class="mySlides fade">
  <div>
    <nav>
  <label class="logo">ADMIN</label>
  
  </label>
  <ul>
  <li><a class="active" href="#">Home</a></li>
  <li><a href="adminapproval.php">REGISTER APPROVAL</a></li>
    <li><a href="confirmationbooking.php">BOOkING APPROVAL</a></li>
    <li><a href="adminviewbooking.php">VIEW BOOKED HISTORY</a></li>
    <li><a href="adminmail.php">CONTACT USER</a></li>
    <li><a href="adminmailview.php">SENT MESSAGES</a><li>
    <li><a href="userqueryadmin.php">USER QUERY</a><li>
    <li><a href="index.php">LOG OUT</a></li>
    
  </ul>
</nav>
  </div>
  <img src="image\burnner.jpeg" style="width:100%">
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>

</body>
</html>