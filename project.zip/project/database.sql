-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 07:49 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(90) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('raje', 'raje19');

-- --------------------------------------------------------

--
-- Table structure for table `adminmail`
--

CREATE TABLE `adminmail` (
  `user` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `refid` mediumtext,
  `sub` varchar(100) DEFAULT NULL,
  `state` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmail`
--

INSERT INTO `adminmail` (`user`, `email`, `refid`, `sub`, `state`) VALUES
('vasanthi s', 'vasanthi@gmail.com', '71772117149', 'your ref id 71772117149. thanks for booking', 'sent'),
('poorna', 'poornasrip2003@gmail.com', '71772117131', 'it is very helpful', 'sent'),
('samy', 'samy@gmail.com', '12345678910', 'sucessfully registered', 'viewed');

--
-- Triggers `adminmail`
--
DELIMITER $$
CREATE TRIGGER `adminmaildeletion` BEFORE DELETE ON `adminmail` FOR EACH ROW begin
insert into adminmaildeleted(user,email,refid,sub)
values(old.user,old.email,old.refid,old.sub);
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `adminmaildeleted`
--

CREATE TABLE `adminmaildeleted` (
  `user` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `refid` varchar(30) DEFAULT NULL,
  `sub` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmaildeleted`
--

INSERT INTO `adminmaildeleted` (`user`, `email`, `refid`, `sub`) VALUES
('deepika', 'deepi@gmail.com', '71772117301', 'thank you for registering'),
('deepika', 'deepi@gmail.com', '71772117301', 'your ref id is 71772117301'),
('disha', 'disha@gmail.com', '71772117306', 'thank you for registering'),
('periyasamy', 'periyasamy@gmail.com', '71325634001', 'thank you for registering'),
('periyasamy', 'periyasamy@gmail.com', '713', '');

-- --------------------------------------------------------

--
-- Table structure for table `available`
--

CREATE TABLE `available` (
  `stock` int(11) DEFAULT NULL,
  `sno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `available`
--

INSERT INTO `available` (`stock`, `sno`) VALUES
(100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `confirmedbooking`
--

CREATE TABLE `confirmedbooking` (
  `refid` mediumtext,
  `email` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `confirmedbooking`
--

INSERT INTO `confirmedbooking` (`refid`, `email`) VALUES
('71772117149', 'vasanthi@gamil.com'),
('71772117306', 'disha@gmail.com'),
('71325634001', 'periyasamygoundar@gmail.com'),
('12345678910', 'samy@gmail.com'),
('12345678910', 'samy@gmail.com'),
('12345678910', 'samy@gmail.com'),
('12345678910', 'samy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `denied`
--

CREATE TABLE `denied` (
  `name` varchar(34) DEFAULT NULL,
  `mobile` mediumtext,
  `email` varchar(50) DEFAULT NULL,
  `aadhar` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `denied`
--

INSERT INTO `denied` (`name`, `mobile`, `email`, `aadhar`) VALUES
('preethi', '347320985', 'priyu@gmail.com', '675634212222'),
('', '', '', ''),
('', '', '', ''),
('', '', '', ''),
('', '', '', ''),
('', '', '', ''),
('poorna', '6666666666', 'poorna@gmail.com', '364578819202'),
('poorna', '6666666666', 'poor@gmail.com', '364578819202'),
('poorna', '7777777777', 'poor@gmail.com', '78654567345'),
('poorna', '9999999999', 'fehg@gmail.com', '2346782121'),
('poorna', '8888888888', 'poor@gmail.com', '78654567345'),
('poorna', '7777777777', 'diya@gmail.com', '78654567345'),
('poorna', '9876543210', 'ruth.71772117135@gct.ac.in', '777777778888'),
('preethi', '5555544444', 'pree@gmail.com', '567434561221'),
('preethi', '5555544444', 'pree@gmail.com', '78654567345'),
('preethi', '9025812842', 'pree@gmail.com', '84738507460754'),
('preethi', '5555544444', 'pree@gmail.com', '84738507460754'),
('preethi', '909090909090', 'saha@gmail.com', '675634212222'),
('preethi', '657983546', 'riya@gmail.com', '77899878708'),
('mhdskjhe', '9500278137', 'sin@gmail.com', '2346782121'),
('menaka', '9876543210', 'menaka@gmail.com', NULL),
('rajeswari', '9443648681', '71772117131@gct.ac.in', NULL),
('santhiya', '9025812842', 'santhiyasrip1999@gmail.com', '2147483647'),
('keerthana', '8094856789', 'keerthanar23504@gmail.com', NULL),
('sankari', '4586785497', 'sankari@gmail.com', '0');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mobile` varchar(14) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `status` varchar(11) DEFAULT NULL,
  `refid` mediumtext,
  `aadhar` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`name`, `email`, `address`, `mobile`, `gender`, `status`, `refid`, `aadhar`) VALUES
('rahini', 'rahi@gmail.com', 'djfherlghtwrhj pudague', '908768907', 'female', 'approved', '1111666678', '345623124532'),
('aarav', 'aarav@gmail.com', '22 nalliyagoundampudur iyyampalayam kodumudi 639431', '9087564323', 'male', 'approved', '3345', '345678819201'),
('aarav', 'aarav@gmail.com', '22 nalliyagoundampudur iyyampalayam kodumudi 639431', '9087564323', 'male', 'approved', '3345', '345678819201'),
('kavitha', 'kavi@gmail.com', 'trichy', '9500278137', 'male', 'approved', '71772117190', '543421787976'),
('deepika', 'deepi@gmail.com', '82,EID PARRY PUGALUR 639113', '76959556677', 'female', 'approved', '71772117301', '345678819201'),
('Vasanthi.S', 'vasanthi@gamil.com', '16,pattammal compound,YMR patti,Dindigul.', '7200472805', 'female', 'approved', '71772117149', '678434567890'),
('disha', 'disha@gmail.com', '12,gandhi street,srinagar,banglore-642341', '9786431034', 'female', 'approved', '71772117306', '707563857936'),
('periyasamy', 'periyasamygoundar@gmail.com', '12,sendhur nagar,2nd cross,pugalur-639006', '9443638681', 'male', 'approved', '71325634001', '364589099202'),
('samy', 'samy@gmail.com', '1 st cross sendhur nagar, pugalur-639113 ', '8903602217', 'male', 'approved', '12345678910', '364578812301');

--
-- Triggers `details`
--
DELIMITER $$
CREATE TRIGGER `deniedvalue` BEFORE DELETE ON `details` FOR EACH ROW begin
insert into denied(name,mobile,email,aadhar)
values(old.name,old.mobile,old.email,old.aadhar);
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `id`
--

CREATE TABLE `id` (
  `refid` mediumtext,
  `email` varchar(40) DEFAULT NULL,
  `dated` date DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `id`
--

INSERT INTO `id` (`refid`, `email`, `dated`, `status`) VALUES
('6785432', 'keerthanar23504@gmail.com', NULL, NULL),
('6785432', 'keerthanar23504@gmail.com', NULL, NULL),
('5674321', '71772117131@gct.ac.in', NULL, NULL),
('509876256', 'sankari@gmail.com', NULL, NULL),
('71772117190', 'kavi@gmail.com', '2023-11-03', 'approved'),
('71772117149', 'vasanthi@gamil.com', '2023-05-03', 'approved'),
('71772117306', 'disha@gmail.com', '2023-04-05', 'approved'),
('71325634001', 'periyasamygoundar@gmail.com', '2023-05-03', 'approved'),
('12345678910', 'samy@gmail.com', '2023-05-07', 'approved'),
('12345678910', 'samy@gmail.com', '2023-05-08', 'approved'),
('12345678910', 'samy@gmail.com', '2003-05-02', 'approved');

--
-- Triggers `id`
--
DELIMITER $$
CREATE TRIGGER `confirmbooking` BEFORE UPDATE ON `id` FOR EACH ROW begin
insert into confirmedbooking(refid, email)
values(old.refid,old.email);
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(24) DEFAULT NULL,
  `password` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('santhiya', 30);

-- --------------------------------------------------------

--
-- Table structure for table `logincredential`
--

CREATE TABLE `logincredential` (
  `username` varchar(36) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `mobile` varchar(12) DEFAULT NULL,
  `gender` varchar(7) DEFAULT NULL,
  `password` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logincredential`
--

INSERT INTO `logincredential` (`username`, `email`, `mobile`, `gender`, `password`) VALUES
('santhiya', 'santhiyasrip1999@gmail.com', '9025812842', 'female', '30'),
('vinothini', 'vinothinisaravanan2004@gmail.com', '9025812842', 'female', '2004'),
('suvathy', 'suva.71772117145@gct.ac.in', '9363345232', 'female', 'suva'),
('keerthana', 'keerthanar23504@gmail.com', '8056566704', 'female', 'keerthana'),
('ruthra', 'ruth.71772117135@gct.ac.in', '9500278137', 'female', 'ruthra'),
('ruthra', 'ruth.71772117135@gct.ac.in', '9500278137', 'female', 'ruthra'),
('menaka', 'menaka@gmail.com', '9876543210', 'female', 'menaka'),
('rajeswari', '717772117131@gct.ac.in', '9443648681', 'female', 'raje'),
('ruthra', 'ruth.71772117135@gct.ac.in', '99998888822', 'female', 'ruthra'),
('sankari', 'sankari@gmail.com', '5677883782', 'female', 'san'),
('preethi', 'pree@gmail.com', '5555544444', 'female', 'pree'),
('poorna', 'poor@gmail.com', '980875632', 'female', 'poo'),
('kavitha', 'kavi@gmail.com', '6787543246', 'female', 'kavi'),
('Vasanthi.S', 'vasanthi@gamil.com', '7200472805', 'female', 'vasanthi'),
('disha', 'disha@gmail.com', '9786431034', 'female', 'disha'),
('periyasamy', 'periyasamygoundar@gmail.com', '9443638681', 'male', '12345'),
('periyasamy', 'periyasamygoundar@gmail.com', '9443638681', 'male', '12345'),
('samy', 'samy@gmail.com', '8903602217', 'male', 'samy');

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE `mail` (
  `email` varchar(40) DEFAULT NULL,
  `subject` varchar(80) DEFAULT NULL,
  `body` varchar(126) DEFAULT NULL,
  `name` varchar(34) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `refid` mediumtext,
  `email` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`refid`, `email`) VALUES
('71772117167', 'diya@gmail.com'),
('1111666678', 'rahi@gmail.com'),
('71772117190', 'kavi@gmail.com'),
('71772117301', 'deepi@gmail.com'),
('71772117149', 'vasanthi@gamil.com'),
('71772117306', 'disha@gmail.com'),
('71325634001', 'periyasamygoundar@gmail.com'),
('12345678910', 'samy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `userquery`
--

CREATE TABLE `userquery` (
  `user` varchar(29) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `refid` mediumtext,
  `sub` varchar(100) DEFAULT NULL,
  `state` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userquery`
--

INSERT INTO `userquery` (`user`, `email`, `refid`, `sub`, `state`) VALUES
('poorna', 'poornasrip2003@gmail.com', '71772117131', 'order delivered at time', 'viewed'),
('periyasamy', 'periyasamy@gmail.com', '71325634001', 'when will my booking get registered', 'viewed'),
('samy', 'samy@gmail.com', '12345678910', 'when will be approved', 'viewed');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
