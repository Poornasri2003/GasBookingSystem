<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include 'connection.php';
$sql = "SELECT * from details where status= 'pending'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='5'><tr>
<th>name</th>
<th>mail</th>
<th>address</th>
<th>mobile</th>
<th>gender</th>
<th>status</th>
</tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>".$row["name"]."</td><td>".$row["email"]."</td> <td>".$row["address"]."</td><td>".$row["mobile"]."</td>
<td>".$row["gender"]."</td><td>".$row["status"]."</td> 
"?><td> 
<form action="approval.php" method="POST">
<input type="hidden" name="user" value="<?php echo $row['name'];?>">
  <input type="hidden" name="mobile" value="<?php echo $row['mobile'];?>">
  <input type="hidden" name="email" value="<?php echo $row['email'];?>">
<input type="submit" name="approve" value="approve">
<input type="submit" name="deny" value="deny">
</form>
</td>
</tr>";
<?php
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
</body>
</html>