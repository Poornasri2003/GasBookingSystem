<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>adminsent</title>
</head>
<body>
    <a href="admindash.php"><h1>go home</h1></a>
<?php
include 'connection.php';
$sql = "SELECT * from userquery";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='10'><tr>
<th>name</th>
<th>email</th>
<th>refid</th>
<th>subject</th>
<th>status</th>
</tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>".$row["user"]."</td><td>".$row["email"]."</td> <td>".$row["refid"]."</td><td>".$row["sub"]."</td>
<td>".$row["state"]."</td>
"?><td> 
<form action="delete2.php" method="POST">
<input type="hidden" name="sub" value="<?php echo $row['sub'];?>">
<input type="submit" name="view" value="view">
<input type="submit" name="delete" value="delete">
</form>
</td>
</tr>";
<?php
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
</body>
</html>