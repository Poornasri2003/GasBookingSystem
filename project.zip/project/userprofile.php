<?php
include 'connection.php';
$aadhar=$_POST['aadhar'];
$sql= "SELECT * from details where aadhar='$aadhar'";
$result=mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width, initial-scale=1.0">
            <title>check details</title>
            <link rel="stylesheet" type="text/css" href="signup.css">
        </head>
        <body background="image\yyy.png">
          
          <div id="form" >
          <form name="form" action="booking.php" method="POST">
        <label >Refid:</label>
        <input type="text" id="refid" name="refid" value="<?php  echo''.$row['refid'];?>">
        <label>Email:</label>
              <input type="email" id="email" name="email" value="<?php echo''.$row['email'];?>" ><br>
              <label>Username:</label>
              <input type="user" id="user" name="user" value="<?php echo''.$row['name'];?>" >
              <label>Mobile:</label>
              <input type="text" id="mobile" name="mobile" value="<?php echo''.$row['mobile'];?>" >
              <label>Address:</label>
              <input type="text" id="address" name="address" value="<?php echo''.$row['address'];?>" >
              <label>aadhar:</label>
              <input type="text" id="aadhar" name="aadhar" value="<?php echo''.$row['aadhar'];?>" ><br>
              <label>gender:</label>
              <input type="text" id="gender" name="gender" value="<?php echo''.$row['gender'];?>" >
              <h1><a href="userdash.php">Go back</a></h1>
              
    </form>
        </div>
        </body>
        </html>
    <?php
    }
  } 

else{
    echo '<script>
    alert("details not found")
    </script>';

}
?>