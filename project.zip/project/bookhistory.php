<?php
include 'connection.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="bookhistory.css">
    <title>Document</title>
</head>
<body>
    <a href="userdash.php">go home</a>
<?php

$refid=$_POST['refid'];
$sql = "SELECT * from id where refid= '$refid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='10'><tr>
<th>dated</th>
<th>status</th>
</tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["dated"]."</td><td>".$row["status"]."</td> 
"?><td> 
</tr>
<?php }
?>
</body>
</html>
<?php
}
else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>