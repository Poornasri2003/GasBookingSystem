<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=<, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Document</title>
  
</head>
<body background="image\yyy.png">
  
  <div id="form" >
    <h1>Login form</h1>
    <form name="form" action="login.php" method="POST">
      <label >Username:</label>
      <input type="text" id="user" name="user"><br><br>
      <label>Password:</label> 
      <input type="password" id="pass" name="pass"><br><br>
      <input type="submit"   value="submit">
      <br>
      <a href="signup.html"><b><h1>Sign up</h1></b>
    </form>
</div>
</body>
</html>