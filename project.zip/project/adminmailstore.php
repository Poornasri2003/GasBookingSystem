<?php
include 'connection.php';
$state="sent";
$user=$_POST['user'];
$email=$_POST['email'];
$refid=$_POST['refid'];
$sub=$_POST['sub'];
$sql = "INSERT INTO adminmail values('$user','$email','$refid','$sub','$state')";
/*
if ($conn->query($sql) === TRUE) {
  echo '<script>
    window.location.href="admindash.php";
    alert("your query or message sent to user dashboard successfully");
    </script>' ;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
*/
$conn->close();
?>