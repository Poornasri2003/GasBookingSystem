<?php
include("connection.php");
$username=$_POST['user'];
$password=$_POST['pass'];
$sql= "select * from logincredential where username='$username' and password='$password'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$count=mysqli_num_rows($result);
if($count==1)
{
    
    echo '<script>
    window.location.href="userdash.php";
    
    alert("successfully logged in thanks");
    </script>' ;
}
else
{
    echo '<script>
    window.location.href= "index.php";
alert("login failed invalid user");
</script> ';
}

?>