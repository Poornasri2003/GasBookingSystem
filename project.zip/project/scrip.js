function sendMail(){
    let parms={
        name:document.getElementById("user").value,
        email: document.getElementById("email").value,
        subject: document.getElementById("refid").value,
        message:document.getElementById("mobile").value,
  }
  emailjs.send("service_z0jdv69","template_wlwgjop",parms).then(alert("booking has been done please wait for some days for approval!!"));
}