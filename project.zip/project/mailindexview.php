<?php
include 'connection.php';
if(isset($_POST['submit']))
{
$refid=$_POST['refid'];
$sql="SELECT * from adminmail where refid= '$refid' ";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  
<?php

if ($result->num_rows > 0) {
  echo "<table border='5'><tr>
<th>message</th>

</tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>".$row["sub"]."</td>
"?><td> 
<form action="inbox.php" method="POST">
<input type="hidden" name="sub" value="<?php echo $row['sub'];?>">
  
<input type="submit" name="view" value="view">
<input type="submit" name="delete" value="delete">
</form>
</td>
</tr>";
<?php
  }
  echo "</table>";
} }else {
  echo "0 results";
}
$conn->close();
?>
</body>
</html>