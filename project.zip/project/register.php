<?php
include 'connection.php';
  $name=$_POST['user'];
  $email=$_POST['mail'];
  $address=$_POST['address'];
  $mobile=$_POST['mobile'];
  $gender=$_POST['gender'];
  $aadhar=$_POST['aadhar'];
  $status="pending";
  $refid= 0;
 $sql = "INSERT INTO details values('$name','$email','$address','$mobile','$gender','$status',$refid,'$aadhar')";

if ($conn->query($sql) === TRUE) {
  echo '<script>
    window.location.href="userdash.php";
    alert("waiting for approval of the register.Please check your profile once the admin generates the referenceid");
    </script>' ;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
