<?php
include 'connection.php';
if(isset($_POST['delete']))
{
  $subject=$_POST['sub'];
  $select="DELETE from userquery where sub='$subject'";
  $result=mysqli_query($conn,$select);
  echo "<script>
  alert('deleted successful!!');
  window.location.href='admindash.php';
  </script>";
}
if(isset($_POST['view']))
{
  $subject=$_POST['sub'];
  $select="UPDATE  userquery set state='viewed' where sub='$subject'";
  $result=mysqli_query($conn,$select);
  echo "<script>
  alert('message status updated');
  window.location.href='userqueryadmin.php';
  </script>";

}
?>
