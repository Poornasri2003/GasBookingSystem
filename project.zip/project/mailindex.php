<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>adminmessages</title>
    <link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body background="image\burnner.jpeg">

    
  <div id="form" >
    <form name="form" action="mailindexview.php" method="POST">
      <label >email:</label>
      <input type="text" id="email" name="email"><br><br>
      <label>refid:</label> 
      <input type="text" id="refid" name="refid"><br><br>
      <input type="submit"  name="submit" value="submit">
      <br>

</form>
</div>
</body>
</html>